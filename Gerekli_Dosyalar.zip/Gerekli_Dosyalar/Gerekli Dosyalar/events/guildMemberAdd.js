module.exports = member => {
    let username = member.user.username;
    member.sendMessage('https://media.giphy.com/media/eSQFIjNhmeX28/giphy.gif Selamlar,Değerli **' + username + '** Discord Sunucuma Hoşgeldin :kissing_heart: #kurallar a bakmayı unutma,lazım olacağından eminim. :thinking: Keyifli Vakit Geçirmen Dileğiyle https://gph.is/2VhWm6k :wink:');

};
